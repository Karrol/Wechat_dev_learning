Page({
  onShareAppMessage() {
    return {
      title: '小程序云开发文档',
      path: 'page/cloud/pages/doc-web-view/doc-web-view'
    }
  },
})
